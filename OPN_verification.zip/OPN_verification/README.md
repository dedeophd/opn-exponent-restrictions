# OPN computational verification package

Companion to "An Exponent Restriction for Odd Perfect Numbers Not Divisible by Three", M. R. DeDeo.

## Reproduction
Extract OPN_verification.zip, preserve its directory structure, and run from the OPN_verification directory:

    python3 verify_all.py

Python 3.8 or later is required. No third-party packages are needed. The tested interpreter is recorded in reproduction_receipt.json.
The driver checks 17 SHA-256 manifest entries, copies verification/ to a temporary directory, and runs five tasks there. Each task has a 120-second timeout. A timeout on slower hardware is not a mathematical counterexample. A successful run prints a JSON object with status PASS and five PASS check results. To retain a new receipt, redirect output to a new file, for example:

    python3 verify_all.py > new_reproduction_receipt.json

## Correspondence to the article
- verification/opn_pivot16/verify_residue_exclusion.py generates source factorizations and bounds (Lemma 2.4).
- verification/opn_audit17/check_certificate.py checks the source certificate; it is invoked by the two-exception verification task.
- verification/opn_stage18/verify_two_exception_bounds.py checks the finite bounds used in Proposition 3.1.
- verification/opn_stage19/verify_three_output_exclusion.py checks the finite source bounds, output enumeration, and tail comparisons (Lemmas 4.2-4.4).
- verification/opn_stage19/check_head_independently.py checks the finite maximum by a separate implementation (Lemma 4.3).
- verification/opn_review25/review_three_exception.py checks the enumeration using unordered output supports.
- verification/opn_stage21/verify_forced_families.py checks the seed inventory (Proposition 5.3).

Expected results include 907360 role-weighted configurations, maximum 538811/328320 at (q,r,s)=(13,7,31), and 99 excluded subsets with 17 inclusion-minimal members among 511 nonempty subsets.

## Files and scope
This archive contains eight Python programs, seven JSON records (including reproduction_receipt.json), this README, MANIFEST.sha256, and two legacy listing wrappers: nineteen files in total.
The existing verification/ subdirectories are preserved because programs depend on relative paths. The six JSON records in those subdirectories are archived computation records. The top-level reproduction_receipt.json records the fresh run of this submission package.
MANIFEST.sha256 hashes seventeen files: it excludes itself and the top-level reproduction receipt. File hashes establish byte consistency, not mathematical correctness. The programs check finite calculations; mathematical reductions and infinite-tail arguments remain in the article. These checks are not external peer review.
OPN_py_listings.tex and OPN_json_listings.tex are optional legacy AMS listing wrappers; they are not used to run verification. The SIAM-formatted combined listings PDF and source are distributed separately.
