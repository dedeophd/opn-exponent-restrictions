"""Exact finite certificate for the exclusion of two exceptional components.

Uses standard-library integer/rational arithmetic. The preceding proofs supply
the bounded output-prime ranges and the analytic infinite-tail argument.
Run: python3 opn_stage19/verify_three_output_exclusion.py
"""
from fractions import Fraction as F
from itertools import combinations
from math import isqrt
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
source = ROOT / 'opn_pivot16/residue_exclusion_certificate.json'
previous = json.loads(subprocess.check_output([sys.executable,
    str(ROOT/'opn_audit17/check_certificate.py'), str(source)], text=True))
rows = json.loads(source.read_text())['rows']


def require(test, message):
    if not test:
        raise ValueError(message)


def prime(n):
    return n >= 2 and all(n % d for d in range(2, isqrt(n)+1))


require(previous['status'] == 'PASS', 'input certificate failed')
# Two output primes both 7 modulo 12: complete reuse of certified factorizations.
minima = {}
for row in rows:
    ff = row['factorization']
    if len(ff) == 2 and all(v % 12 == 7 for v, e in ff):
        for (_, a), (_, b) in (ff, ff[::-1]):
            if a+b <= 6:
                minima[a, b] = min(row['p'], minima.get((a, b), row['p']))
require(minima == {(1, 1): 11, (1, 2): 521, (2, 1): 521}, 'mixed minima')
C7 = F(7, 6)*F(19, 18)*F(5, 4)*F(17, 16)
for a in range(1, 6):
    for b in range(1, 7-a):
        lower = minima.get((a, b), 1001)
        C7 *= F(lower, lower-1)
B7 = C7/(1-F(1024, 28125))
require(B7 < F(19, 10), '7-mod-12 kernel bound')
require(F(13, 5)**2 < 7 and F(13, 3)**2 < 19, 'root bounds')
require(F(8, 13)*F(10, 13) > F(4, 9), 'third output coefficient')
require(F(19, 10)*F(10000, 9999)*F(22, 21) == F(38000, 19089) < 2,
        'Euler cutoff bound')

# Complete output-prime lists, independently cross-checked by a sieve.
R = [p for p in range(7, 1600, 3) if prime(p)]
Q = [p for p in range(13, 10000, 12) if prime(p)]
sieve = [True]*10000
sieve[0] = sieve[1] = False
for p in range(2, 100):
    if sieve[p]:
        for n in range(p*p, 10000, p):
            sieve[n] = False
require(R == [p for p in range(7, 1600) if p % 3 == 1 and sieve[p]], 'R completeness')
require(Q == [p for p in range(13, 10000) if p % 12 == 1 and sieve[p]], 'Q completeness')
require(len(R) == 121 and len(Q) == 300, 'prime-list counts')

# Aggregate head factors by their exact prime support. No eligible row is lost.
support_factors = {}
for row in rows:
    support = tuple(v for v, e in row['factorization'])
    if len(support) <= 3:
        support_factors[support] = support_factors.get(support, F(1))*F(row['p'], row['p']-1)
base = {v: F(v, v-1)*support_factors.get((v,), F(1)) for v in set(R+Q)}
pair = {(u, v): support_factors.get(tuple(sorted((u, v))), F(1))
        for u in R for v in Q if u != v}
count = 0
maximum = F(0)
maximizer = None
for r, s in combinations(R, 2):
    fixed = base[r]*base[s]*support_factors.get((r, s), F(1))
    for q in Q:
        if q in (r, s):
            continue
        if q >= 1600 and (r % 12 == 1 or s % 12 == 1):
            continue
        head = fixed*base[q]*pair[r, q]*pair[s, q]
        head *= support_factors.get(tuple(sorted((q, r, s))), F(1))
        require(head < F(5, 3), 'head bound failed for ' + repr((q, r, s)))
        count += 1
        if head > maximum:
            maximum, maximizer = head, (q, r, s)
require(count == 907360, 'configuration count')
require(maximum == F(538811, 328320) and maximizer == (13, 7, 31), 'maximum')

# Independent formula for the number of configurations, not the nested-loop count.
require(count == sum(sum(q not in (r, s) for q in Q if
    q < 1600 or (r % 12 == 7 and s % 12 == 7)) for r, s in combinations(R, 2)),
    'configuration count cross-check')

# Rational upper bounds for reciprocal square roots of 7,13,19.
xs = [F(1000, isqrt(1000000*p)) for p in (7, 13, 19)]
for p, x in zip((7, 13, 19), xs):
    require(0 < x < 1 and p*x*x >= 1, 'reciprocal-root bound')
coeff = [F(1)]+[F(0)]*6
for x in xs:
    for j in range(1, 7):
        coeff[j] += x*coeff[j-1]
full = F(1)
for x in xs:
    full /= 1-x
delta = 2*(full-sum(coeff))
# Check the truncated coefficients against direct triple enumeration.
direct = sum(xs[0]**a*xs[1]**b*xs[2]**c
             for a in range(7) for b in range(7-a) for c in range(7-a-b))
require(sum(coeff) == direct and 0 < delta < F(3, 100), 'tail bound')
large_low_degree_slots = sum((j+1)*(j+2)//2 for j in range(1, 7))-3*5
require(large_low_degree_slots == 68, 'low-degree count')
K = F(1001, 1000)**68/(1-F(3, 100))
require(K < F(10, 9), 'large-source product bound')
require(F(5, 3)*F(10, 9) == F(50, 27) < 2, 'final contradiction')
report = dict(status='PASS', previous_certificate_check=previous,
    both_7_mod_12_minima=[dict(a=a, b=b, lower=p) for (a, b), p in sorted(minima.items())],
    both_7_mod_12_bound=str(B7), exceptional_candidates=R, euler_candidates=Q,
    checked_configurations=count, maximum_head=str(maximum), maximizing_q_r_s=maximizer,
    maximizing_small_sources=[row['p'] for row in rows
        if set(v for v,e in row['factorization']) <= set(maximizer)],
    reciprocal_root_upper_bounds=[str(x) for x in xs], tail_log_upper_bound=str(delta),
    low_degree_slots=68, large_source_product_bound=str(K), final_bound='50/27',
    checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    input_certificate_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    scope='Exact finite arithmetic; analytic reductions require the accompanying proof.')
out = Path(__file__).with_name('three_output_certificate.json')
out.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k: report[k] for k in ('status', 'checked_configurations',
    'maximum_head', 'maximizing_q_r_s', 'maximizing_small_sources', 'final_bound')}))
