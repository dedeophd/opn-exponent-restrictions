"""Second exact head check: direct radical divisibility, no support-product cache.
Does not import or run the Stage 19 generator. Analytic claims are outside scope.
"""
from pathlib import Path
from itertools import combinations, chain
from math import prod
import hashlib
import json

root = Path(__file__).resolve().parent.parent
raw = (root/'opn_pivot16/residue_exclusion_certificate.json').read_bytes()
evidence = json.loads((root/'opn_stage19/three_output_certificate.json').read_text())
if hashlib.sha256(raw).hexdigest() != evidence['input_certificate_sha256']:
    raise ValueError('input certificate hash mismatch')
rows = json.loads(raw)['rows']
factors = [(prod(v for v,e in row['factorization']), row['p']) for row in rows]
sieve = bytearray(b'\x01')*10000
sieve[:2] = b'\x00\x00'
for p in range(2, 100):
    if sieve[p]:
        for m in range(p*p, 10000, p):
            sieve[m] = 0
R = [p for p in range(7,1600) if sieve[p] and p%3 == 1]
Q = [p for p in range(13,10000) if sieve[p] and p%12 == 1]
if R != evidence['exceptional_candidates'] or Q != evidence['euler_candidates']:
    raise ValueError('candidate list mismatch')
R7 = [r for r in R if r%12 == 7]
# Two disjoint case generators, instead of filtering the full triple loop.
small = ((q,r,s) for q in Q if q<1600 for r,s in combinations(R,2) if q!=r and q!=s)
large = ((q,r,s) for q in Q if q>=1600 for r,s in combinations(R7,2))
best_n, best_d, best_triple, count = 0, 1, None, 0
for q,r,s in chain(small,large):
    P = q*r*s
    num, den = P, (q-1)*(r-1)*(s-1)
    for radical,p in factors:
        if P % radical == 0:
            num *= p
            den *= p-1
    if 3*num >= 5*den:
        raise ValueError('head bound failed at '+repr((q,r,s)))
    if num*best_d > best_n*den:
        best_n, best_d, best_triple = num, den, (q,r,s)
    count += 1
if count != 907360 or 328320*best_n != 538811*best_d or best_triple != (13,7,31):
    raise ValueError('count or maximum mismatch')
print(json.dumps(dict(status='PASS', checked_configurations=count,
    maximum_head='538811/328320', maximizing_q_r_s=best_triple,
    method='Direct radical divisibility and integer cross multiplication',
    checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    scope='Separate implementation of finite head check; not external review.'), indent=2))
