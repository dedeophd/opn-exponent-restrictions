"""Fresh finite arithmetic review. No earlier project code/data are imported.
Analytic completeness and the published prime-power theorem are external proof obligations.
Python standard library only. Writes review_receipt.json alongside this script.
"""
from fractions import Fraction as F
from itertools import combinations
from math import isqrt, prod
from pathlib import Path
import hashlib,json,sys

def check(c,msg):
    if not c: raise ValueError(msg)
# Independently generate every prime needed for candidate lists and trial factors.
flags=bytearray(b'\1')*10000
flags[0]=flags[1]=0
for p in range(2,100):
    if flags[p]:
        flags[p*p:10000:p]=b'\0'*len(range(p*p,10000,p))
primes=[p for p in range(2,10000) if flags[p]]
def factor(n):
    out=[]
    for p in primes:
        if p*p>n: break
        a=0
        while n%p==0: n//=p;a+=1
        if a:out.append((p,a))
    if n>1:out.append((n,1))
    return out
rows=[]
for p in primes:
    if p<=1000 and p%3==2 and p!=2:
        f=factor(p*p+p+1)
        check(prod(v**a for v,a in f)==p*p+p+1,'recomposition')
        check(all(all(v%d for d in range(2,isqrt(v)+1)) for v,a in f),'prime factors')
        rows.append((p,f))
check(len(rows)==86,'source count')
minq={};min7={}
for p,f in rows:
    if len(f)==2:
        for (u,a),(v,b) in (f,list(reversed(f))):
            if a+b<=6:
                if u%12==1:minq[a,b]=min(p,minq.get((a,b),p))
                if u%12==v%12==7:min7[a,b]=min(p,min7.get((a,b),p))
check(minq=={(1,1):29,(1,2):863},'first minima')
check(min7=={(1,1):11,(1,2):521,(2,1):521},'second minima')
x=F(2,5)
delta=2*(x*x/(1-x)**2-sum((j-1)*x**j for j in range(2,7)))
check(delta==F(1024,28125),'two-output tail')
pairs=[(a,b) for a in range(1,6) for b in range(1,7-a)]
def pairproduct(table):
    return prod(F(table.get(ab,1001),table.get(ab,1001)-1) for ab in pairs)
C=F(13,12)*F(7,6)*F(5,4)*F(11,10)*pairproduct(minq)
check(C<F(183,100) and C/(1-delta)<F(19,10),'one exception')
B0=F(1121,638)
check(F(59,58)/F(11,10)*C/(1-delta)<B0<F(9,5),'two output kernel')
check(F(13,12)*F(5,4)*F(11,10)*F(17,16)<2,'two 2-mod3 exceptions')
check(F(9,5)*F(11,10)<2 and F(9,5)*F(17,20)*F(5,4)<2,'mixed exceptions')
check(F(18,5)**2<13 and F(13,5)**2<7,'root bounds 1')
check((1-F(5,18))*(1-F(5,13))==F(4,9),'root coefficient 1')
check(B0*F(1600,1599)*F(26,23)<2,'1600 bound')
B7=F(7,6)*F(19,18)*F(5,4)*F(17,16)*pairproduct(min7)/(1-delta)
check(B7<F(19,10),'two 7-mod12 kernel')
check(F(13,5)**2<7 and F(13,3)**2<19,'root bounds 2')
check(F(8,13)*F(10,13)>F(4,9),'root coefficient 2')
check(F(19,10)*F(10000,9999)*F(22,21)<2,'10000 bound')
R=[p for p in primes if p<1600 and p%3==1]
largeQ=[p for p in primes if p>=1600 and p%12==1]
R7=[p for p in R if p%12==7]
radicals=[(p,prod(v for v,a in f)) for p,f in rows]
best=(0,1);max_support=None;max_sources=None;unordered=0;roles=0

def examine(V,multiplicity):
    global best,max_support,max_sources,unordered,roles
    product=prod(V);num=product;den=prod(v-1 for v in V)
    source=[]
    for p,rad in radicals:
        if product%rad==0:num*=p;den*=p-1;source.append(p)
    check(3*num<5*den,'head upper bound')
    if num*best[1]>best[0]*den:best=(num,den);max_support=V;max_sources=source
    unordered+=1;roles+=multiplicity
# Below 1600 every 1-mod12 output may be designated Eulerian.
for V in combinations(R,3):
    k=sum(v%12==1 for v in V)
    if k:examine(V,k)
# A large output must be Eulerian; the two small outputs must be 7-mod12.
for q in largeQ:
    for r,s in combinations(R7,2):examine((r,s,q),1)
check(roles==907360,'role-weighted coverage')
check(F(*best)==F(538811,328320) and max_support==(7,13,31),'maximum')
check(max_sources==[5,191],'maximizing sources')
# Recompute the high-degree majorant explicitly, with no generating recurrence.
xs=[F(1000,isqrt(1000000*v)) for v in (7,13,19)]
check(all(0<x<1 and v*x*x>=1 for x,v in zip(xs,(7,13,19))),'reciprocal roots')
trunc=sum(xs[0]**a*xs[1]**b*xs[2]**c for a in range(7) for b in range(7-a) for c in range(7-a-b))
D=2*(prod(1/(1-x) for x in xs)-trunc)
low=[(a,b,c) for a in range(7) for b in range(7-a) for c in range(7-a-b) if a+b+c and not (sum(t>0 for t in (a,b,c))==1 and a+b+c>1)]
check(len(low)==68,'low degree slots')
check(0<D<F(3,100),'tail majorant')
K=F(1001,1000)**68/(1-F(3,100))
check(K<F(10,9) and F(5,3)*K<F(50,27)<2,'final bound')
result=dict(status='PASS',python=sys.version,source_count=len(rows),
    independent_unordered_supports=unordered,role_weighted_configurations=roles,
    maximum_head=str(F(*best)),maximizing_support=max_support,maximizing_sources=max_sources,
    two_output_tail=str(delta),two_output_kernel=str(B0),both_7_mod12_kernel=str(B7),
    tail_log_bound=str(D),low_degree_slots=len(low),large_source_bound=str(K),final_bound='50/27',
    source_factorizations=[dict(p=p,factors=f) for p,f in rows],
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    scope='Fresh finite arithmetic and rational comparisons; no prior certificate or script used. Not external or formal proof review.')
Path(__file__).with_name('review_receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('status','independent_unordered_supports','role_weighted_configurations','maximum_head','maximizing_support','final_bound')}))
