"""Read-only checker for Stage 16's finite certificate, Python standard library.

This implementation does not import or run the certificate generator. It checks
finite arithmetic, not the analytic proof or the published Diophantine input.
Usage: python3 check_certificate.py [path/to/residue_exclusion_certificate.json]
"""
import copy
import hashlib
import json
import sys
from fractions import Fraction as Q
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def prime(n):
    if n < 2:
        return False
    if n in (2, 3):
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    d = 5
    while d * d <= n:
        if n % d == 0 or n % (d + 2) == 0:
            return False
        d += 6
    return True


def rational(record):
    require(record['denominator'] > 0, 'nonpositive denominator')
    return Q(record['numerator'], record['denominator'])


def check(data):
    require(data['limit'] == 1000, 'wrong interval')
    expected = [p for p in range(5, 1001, 3) if prime(p)]
    require([row['p'] for row in data['rows']] == expected,
            'missing, duplicated, reordered, or nonprime input')
    require(data['checked_primes'] == len(expected) == 86, 'wrong count')
    minima = {}
    for row in data['rows']:
        p = row['p']
        value = p * p + p + 1
        require(row['phi3'] == value, 'wrong cyclotomic value')
        ff = row['factorization']
        bases = [pair[0] for pair in ff]
        require(bases == sorted(set(bases)), 'repeated or unordered bases')
        remaining = value
        for base, exponent in ff:
            require(prime(base) and type(exponent) is int and exponent > 0,
                    'invalid prime power')
            for _ in range(exponent):
                require(remaining % base == 0, 'factor does not divide')
                remaining //= base
        require(remaining == 1, 'incomplete factorization')
        assignments = []
        if len(ff) == 2:
            for (q, a), (r, b) in (ff, ff[::-1]):
                if q % 12 == 1 and r % 3 == 1 and a + b <= 6:
                    assignments.append(dict(q=q, r=r, a=a, b=b))
                    minima[(a, b)] = min(p, minima.get((a, b), p))
        require(row['assignments'] == assignments, 'wrong assignment list')
    require(minima == {(1, 1): 29, (1, 2): 863}, 'unexpected minima')
    bounds = {(a, j-a): minima.get((a, j-a), 1001)
              for j in range(2, 7) for a in range(1, j)}
    supplied = {(r['a'], r['b']): r['lower_bound'] for r in data['table']}
    require(len(data['table']) == 15 and supplied == bounds, 'wrong bound table')
    finite = Q(13, 12) * Q(7, 6) * Q(5, 4) * Q(11, 10)
    for lower in bounds.values():
        finite *= Q(lower, lower-1)
    # Sum all j>=2 first, then remove j=2,...,6: a different evaluation
    # from the shifted-tail expression in the generating program.
    x = Q(2, 5)
    tail = 2 * (x*x / (1-x)**2
                - sum((j-1) * x**j for j in range(2, 7)))
    total = finite / (1-tail)
    require(tail == Q(1024, 28125), 'tail arithmetic')
    require(rational(data['finite_product']) == finite, 'finite product mismatch')
    require(rational(data['tail_log_bound']) == tail, 'tail record mismatch')
    require(rational(data['total_upper_bound']) == total, 'total mismatch')
    require(finite < Q(183, 100), 'finite comparison failed')
    require(total < Q(183, 100) / (1-tail) < Q(19, 10) < 2,
            'final comparisons failed')
    require(data['verified_total_less_than'] == '19/10', 'bound label mismatch')
    return dict(inputs=len(expected), pairs=len(bounds),
                total_numerator=total.numerator, total_denominator=total.denominator)


def main():
    default = Path(__file__).resolve().parent.parent / 'opn_pivot16' / 'residue_exclusion_certificate.json'
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else default
    raw = path.read_bytes()
    data = json.loads(raw)
    result = check(data)
    # Negative controls guard against a checker that accepts damaged evidence.
    mutations = []
    for name in ('missing_input', 'wrong_factor', 'missing_assignment', 'wrong_tail'):
        bad = copy.deepcopy(data)
        if name == 'missing_input':
            bad['rows'].pop()
        elif name == 'wrong_factor':
            bad['rows'][0]['factorization'][0][0] += 2
        elif name == 'missing_assignment':
            next(row for row in bad['rows'] if row['assignments'])['assignments'] = []
        else:
            bad['tail_log_bound']['numerator'] += 1
        try:
            check(bad)
        except ValueError:
            mutations.append(name)
        else:
            raise ValueError('negative control accepted: ' + name)
    result.update(status='PASS', negative_controls_rejected=mutations,
                  certificate_sha256=hashlib.sha256(raw).hexdigest(),
                  checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  scope='Finite arithmetic only; separate implementation, not external review.')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
