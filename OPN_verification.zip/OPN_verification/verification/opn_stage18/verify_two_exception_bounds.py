"""Exact arithmetic checks for the two-exception restriction.

Run from any directory. The project layout (also supplied in the ZIP) must
include opn_audit17/check_certificate.py and the Stage 16 JSON certificate.
This checks finite arithmetic, not the analytic proof or novelty.
"""
from fractions import Fraction as Q
from math import isqrt
from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
certificate = root / 'opn_pivot16' / 'residue_exclusion_certificate.json'
checker = root / 'opn_audit17' / 'check_certificate.py'
prior = json.loads(subprocess.check_output(
    [sys.executable, str(checker), str(certificate)], text=True))


def require(condition, message):
    if not condition:
        raise ValueError(message)


require(prior['status'] == 'PASS', 'prior certificate failed')
for p, factors in [(11, [7, 19]), (23, [7, 79]), (47, [37, 61])]:
    require(p*p+p+1 == factors[0]*factors[1], 'pure-source factorization')
    require(all(all(f % d for d in range(2, isqrt(f)+1)) for f in factors),
            'nonprime factor')
B = Q(19, 10) * Q(59, 58) / Q(11, 10)
require(B == Q(1121, 638) < Q(9, 5), 'two-output bound')
require(Q(13, 12)*Q(5, 4)*Q(11, 10)*Q(17, 16) < 2,
        'both exceptions 2 mod 3')
require(Q(9, 5)*Q(11, 10) == Q(99, 50) < 2, 'mixed case s>=11')
require(Q(9, 5)*Q(17, 20)*Q(5, 4) == Q(153, 80) < 2,
        'mixed case s=5')
require(Q(18, 5)**2 < 13 and Q(13, 5)**2 < 7, 'square root bounds')
require((1-Q(5, 18))*(1-Q(5, 13)) == Q(4, 9), 'geometric denominator')
tail = Q(9, 2*(40-1))
require(40**2 == 1600 and tail == Q(3, 26), 'third output tail')
upper = B * Q(1600, 1599) / (1-tail)
require(upper == Q(1793600, 902451) < 2, 'final exclusion bound')

# Candidate count by sieve, independently compared with trial division.
sieve = [True]*1600
sieve[0] = sieve[1] = False
for p in range(2, 40):
    if sieve[p]:
        for n in range(p*p, 1600, p):
            sieve[n] = False
candidates = [p for p in range(7, 1600, 3) if sieve[p]]
trial = [p for p in range(7, 1600) if p % 3 == 1
         and all(p % d for d in range(2, isqrt(p)+1))]
require(candidates == trial and len(candidates) == 121, 'candidate count')
pair_count = len(candidates)*(len(candidates)-1)//2
require(pair_count == 7260, 'pair count')
report = dict(status='PASS', prior_certificate_check=prior,
              two_output_bound=str(B), third_output_log_bound=str(tail),
              final_upper_bound=str(upper), exceptional_prime_candidates=candidates,
              candidate_count=len(candidates), unordered_pair_count=pair_count,
              checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              scope='Exact arithmetic checks; not formal proof verification or priority clearance.')
out = Path(__file__).with_name('two_exception_checks.json')
out.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k: report[k] for k in ('status', 'two_output_bound',
    'third_output_log_bound', 'final_upper_bound', 'candidate_count', 'unordered_pair_count')}))
