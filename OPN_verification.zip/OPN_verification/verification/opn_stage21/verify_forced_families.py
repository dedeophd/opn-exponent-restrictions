"""Exact one-step forced-support exclusions; standard library only.
Proves arithmetic certificates, not novelty. No unreviewed input is required.
"""
from fractions import Fraction as F
from itertools import combinations
from math import isqrt, prod
from pathlib import Path
import json

POOL=(5,11,17,23,29,41,47,53,59)


def prime(n):
    return n>=2 and all(n%d for d in range(2,isqrt(n)+1))


def factor(n):
    ans=[]
    d=2
    while d*d<=n:
        e=0
        while n%d==0:
            n//=d; e+=1
        if e: ans.append((d,e))
        d+=1
    if n>1: ans.append((n,1))
    return ans


def require(test, message):
    if not test: raise ValueError(message)


sources={}
for p in POOL:
    ff=factor(p*p+p+1)
    require(prime(p) and p%3==2, 'seed')
    require(prod(v**e for v,e in ff)==p*p+p+1 and all(prime(v) for v,e in ff), 'factorization')
    sources[p]=ff
records=[]
by_seed={}
for size in range(1,len(POOL)+1):
    for S in combinations(POOL,size):
        P=sorted(set(S)|{v for p in S for v,e in sources[p]})
        base=prod(F(p*p+p+1,p*p) for p in P)
        candidates=[(None,base)]+[(q,base*F(q*(q+1),q*q+q+1)) for q in P if q%12==1]
        q,low=min(candidates,key=lambda z:z[1])
        # Recompute every Euler alternative directly, with unreduced integers.
        branches=[]
        for q2,value in candidates:
            facts=[(p,1 if p==q2 else 2) for p in P]
            D=prod(p**e for p,e in facts)
            sigma=prod(sum(p**j for j in range(e+1)) for p,e in facts)
            require(F(sigma,D)==value,'direct divisor arithmetic')
            branches.append({'euler_prime':q2,'divisor':D,'sigma_divisor':sigma,'index':str(value)})
        row={'seed':list(S),'forced_support':P,'distinct_forced_primes':len(P),
             'worst_euler_prime':q,'lower_bound':str(low),'excluded':low>2,'branches':branches}
        records.append(row);by_seed[frozenset(S)]=row
minimal=[]
for row in records:
    S=frozenset(row['seed'])
    if row['excluded'] and not any(other < S and rr['excluded'] for other,rr in by_seed.items()):
        minimal.append(row)
require(len(records)==511 and len(minimal)==17,'inventory count')
for row in records:
    require(row['excluded']==any(set(m['seed'])<=set(row['seed']) for m in minimal),'minimal-family coverage')
require([m['seed'] for m in minimal if len(m['seed'])==4]==
    [[5,11,17,29],[5,11,23,29],[5,11,29,41],[5,11,29,47],[5,11,29,53]],'four-seed cases')
result={'status':'PASS','pool':POOL,'source_factorizations':sources,'checked_subsets':len(records),
        'excluded_subsets':sum(r['excluded'] for r in records),'minimal_families':minimal,
        'all_subsets':records,'scope':'All subsets of the stated pool; minimal for this one-step lower-bound test only.'}
Path(__file__).with_name('forced_family_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'PASS','checked':len(records),'excluded':result['excluded_subsets'],
    'minimal':len(minimal),'forced_prime_count_range':[min(m['distinct_forced_primes'] for m in minimal),max(m['distinct_forced_primes'] for m in minimal)]}))
