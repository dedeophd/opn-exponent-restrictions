"""Exact certificate for the finite part of the no-3 exponent-residue exclusion.
The infinite tail and prime-power lemma are proved/cited in the accompanying text.
Uses only Python standard library; no probabilistic primality or floating arithmetic.
"""
from fractions import Fraction
from math import isqrt, prod
from pathlib import Path
import json

LIMIT = 1000

def is_prime(n):
    return n >= 2 and all(n % t for t in range(2, isqrt(n) + 1))

def factor(n):
    ans = []
    t = 2
    while t*t <= n:
        e = 0
        while n % t == 0:
            n //= t
            e += 1
        if e:
            ans.append([t,e])
        t += 1
    if n > 1:
        ans.append([n,1])
    return ans

# Sieve independently specifies the complete list to be checked.
sieve = [True] * (LIMIT+1)
sieve[:2] = [False,False]
for t in range(2,isqrt(LIMIT)+1):
    if sieve[t]:
        for j in range(t*t,LIMIT+1,t):
            sieve[j] = False
primes = [p for p in range(5,LIMIT+1) if sieve[p] and p % 3 == 2]
rows = []
minima = {}
for p in primes:
    assert is_prime(p)
    value = p*p+p+1
    ff = factor(value)
    assert prod(r**e for r,e in ff) == value
    assert all(is_prime(r) and e > 0 for r,e in ff)
    assignments = []
    if len(ff) == 2:
        for j in range(2):
            q,a = ff[j]
            r,b = ff[1-j]
            if q % 12 == 1 and r % 3 == 1 and a+b <= 6:
                assignments.append({'q':q,'r':r,'a':a,'b':b})
                minima[(a,b)] = min(p,minima.get((a,b),p))
    rows.append({'p':p,'phi3':value,'factorization':ff,'assignments':assignments})
assert minima == {(1,1):29,(1,2):863}
C = Fraction(91,72)*Fraction(5,4)*Fraction(11,10)
table = []
for a in range(1,6):
    for b in range(1,7-a):
        lower = minima.get((a,b),LIMIT+1)
        table.append({'a':a,'b':b,'lower_bound':lower})
        C *= Fraction(lower,lower-1)
assert len(table) == 15
x = Fraction(2,5)
S = 2*x**7*(6/(1-x)+x/(1-x)**2)
assert S == Fraction(1024,28125)
assert C < Fraction(183,100)
assert C/(1-S) < Fraction(19,10) < 2

def rat(x):
    return {'numerator':x.numerator,'denominator':x.denominator}
result = {'limit':LIMIT,'checked_primes':len(primes),'rows':rows,'table':table,
          'finite_product':rat(C),'tail_log_bound':rat(S),
          'total_upper_bound':rat(C/(1-S)),
          'verified_total_less_than':'19/10',
          'scope':'Finite arithmetic certificate, not a bounded search for N.'}
out = Path(__file__).with_name('residue_exclusion_certificate.json')
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checked_primes':len(primes),'low_patterns':len(minima),
                  'mixed_pairs':len(table),'total_bound':rat(C/(1-S)),
                  'all_exact_checks_passed':True}))
