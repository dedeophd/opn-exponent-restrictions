"""Verify packaged hashes and reproduce exact arithmetic in a temporary copy.

This does not verify the analytic proofs or establish novelty.
"""

import hashlib,json,subprocess,sys,tempfile,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent
manifest=ROOT/'MANIFEST.sha256'
if not manifest.exists():raise SystemExit('Missing MANIFEST.sha256')
checked=0
for line in manifest.read_text().splitlines():
    expected,name=line.split('  ',1)
    if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=expected:
        raise SystemExit('Hash mismatch: '+name)
    checked+=1
jobs=[('two_exception','opn_stage18/verify_two_exception_bounds.py'),
      ('three_output','opn_stage19/verify_three_output_exclusion.py'),
      ('separate_head','opn_stage19/check_head_independently.py'),
      ('standalone_review','opn_review25/review_three_exception.py'),
      ('forced_families','opn_stage21/verify_forced_families.py')]
receipt={'status':'PASS','manifest_files':checked,'python':sys.version,'checks':[]}
with tempfile.TemporaryDirectory(prefix='tnp_reproduction_') as tmp:
    dst=Path(tmp)/'verification';shutil.copytree(ROOT/'verification',dst)
    for label,name in jobs:
        r=subprocess.run([sys.executable,str(dst/name)],text=True,capture_output=True,timeout=120)
        if r.returncode:
            raise SystemExit(label+' failed:\n'+r.stdout+r.stderr)
        answer=json.loads(r.stdout)
        if answer.get('status')!='PASS':raise SystemExit(label+' did not pass')
        receipt['checks'].append({'name':label,'result':answer})
print(json.dumps(receipt,indent=2))
