"""Check archive hashes and reproduce finite arithmetic in a temporary copy.

Regenerated records are compared with the archived records. The article
supplies the mathematical reductions and the justification of infinite tails.
"""

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
manifest = ROOT / 'MANIFEST.sha256'
if not manifest.exists():
    raise SystemExit('Missing MANIFEST.sha256')
checked = 0
for line in manifest.read_text().splitlines():
    expected, name = line.split('  ', 1)
    if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
        raise SystemExit('Hash mismatch: ' + name)
    checked += 1

# Each tuple identifies a program, its complete record, and whether that
# record is printed rather than written by the program itself.
jobs = [
    ('source_factors', 'opn_pivot16/verify_residue_exclusion.py',
     'opn_pivot16/residue_exclusion_certificate.json', False),
    ('output_bounds', 'opn_stage18/verify_two_exception_bounds.py',
     'opn_stage18/two_exception_checks.json', False),
    ('three_outputs', 'opn_stage19/verify_three_output_exclusion.py',
     'opn_stage19/three_output_certificate.json', False),
    ('independent_maximum', 'opn_stage19/check_head_independently.py',
     'opn_stage19/independent_head_check.json', True),
    ('independent_review', 'opn_review25/review_three_exception.py',
     'opn_review25/review_receipt.json', False),
    ('forced_divisors', 'opn_stage21/verify_forced_families.py',
     'opn_stage21/forced_family_certificate.json', False),
    ('independent_forced_divisors', 'opn_stage21/check_forced_families_independently.py',
     'opn_stage21/independent_forced_check.json', True),
]


def comparable(record):
    # Interpreter metadata may differ; all mathematical data and hashes must agree.
    result = dict(record)
    result.pop('python', None)
    return result


receipt = dict(status='PASS', manifest_files=checked, python=sys.version, checks=[])
with tempfile.TemporaryDirectory(prefix='opn_reproduction_') as tmp:
    dst = Path(tmp) / 'verification'
    shutil.copytree(ROOT / 'verification', dst)
    for label, program, record, printed_record in jobs:
        run = subprocess.run([sys.executable, str(dst / program)],
                             text=True, capture_output=True, timeout=120)
        if run.returncode:
            raise SystemExit(label + ' failed:\n' + run.stdout + run.stderr)
        answer = json.loads(run.stdout)
        if answer.get('status') != 'PASS':
            raise SystemExit(label + ' did not pass')
        generated = answer if printed_record else json.loads((dst / record).read_text())
        archived = json.loads((ROOT / 'verification' / record).read_text())
        if comparable(generated) != comparable(archived):
            raise SystemExit(label + ': regenerated record differs from archive')
        receipt['checks'].append(dict(name=label, archived_record_matched=True,
                                      result=answer))
print(json.dumps(receipt, indent=2))
