"""Read-only seed-inventory checker using direct integer divisor arithmetic.

Does not import or run the generating program and does not use Fraction.
Usage: python3 check_forced_families_independently.py [certificate.json]
"""

import hashlib
import json
import sys
from math import gcd, isqrt, prod
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    return all(n % d for d in range(3, isqrt(n) + 1, 2))


def ratio_text(n, d):
    g = gcd(n, d)
    return str(n // g) if d == g else str(n // g) + '/' + str(d // g)


def check(data):
    pool = tuple(p for p in range(5, 60) if p % 3 == 2 and prime(p))
    require(tuple(data['pool']) == pool and len(pool) == 9, 'seed pool')
    require(data['seed_exponent'] == 2
            and data['non_euler_output_exponent'] == 4, 'exponent rule')
    trial_primes = [p for p in range(2, 60) if prime(p)]
    factors = {}
    for p in pool:
        n = p*p + p + 1
        ff = []
        for v in trial_primes:
            if v*v > n:
                break
            e = 0
            while n % v == 0:
                n //= v
                e += 1
            if e:
                ff.append([v, e])
        if n > 1:
            ff.append([n, 1])
        require(all(prime(v) for v, e in ff), 'prime output')
        require(prod(v**e for v, e in ff) == p*p+p+1, 'factorization')
        factors[p] = ff
    require(data['source_factorizations'] ==
            {str(p): ff for p, ff in factors.items()}, 'factor records')
    records = {tuple(row['seed']): row for row in data['all_subsets']}
    require(len(records) == len(data['all_subsets']) == 511, 'record count')
    excluded = []
    by_mask = {}
    branches_checked = 0
    for mask in range(1, 1 << len(pool)):
        seed = tuple(p for j, p in enumerate(pool) if mask & (1 << j))
        outputs = sorted({v for p in seed for v, e in factors[p]})
        support = sorted(set(seed) | set(outputs))
        require(not set(seed) & set(outputs), 'source-output disjointness')
        row = records[seed]
        require(row['output_primes'] == outputs
                and row['forced_support'] == support
                and row['distinct_forced_primes'] == len(support), 'support record')
        choices = [None] + [v for v in outputs if v % 12 == 1]
        expected_branches = []
        best = None
        best_q = None
        for q in choices:
            powers = [(v, 2 if v in seed else (1 if v == q else 4))
                      for v in support]
            denominator = prod(v**e for v, e in powers)
            numerator = prod((v**(e+1)-1)//(v-1) for v, e in powers)
            expected_branches.append(dict(euler_prime=q, divisor=denominator,
                                          sigma_divisor=numerator,
                                          index=ratio_text(numerator, denominator)))
            if best is None or numerator*best[1] < best[0]*denominator:
                best = numerator, denominator
                best_q = q
            branches_checked += 1
        n, d = best
        require(row['branches'] == expected_branches, 'Euler-choice records')
        require(row['worst_euler_prime'] == best_q
                and row['lower_bound'] == ratio_text(n, d), 'minimum')
        require(row['excluded'] == (n > 2*d), 'exclusion flag')
        if n > 2*d:
            excluded.append(mask)
        by_mask[mask] = row
    minimal = [m for m in excluded
               if not any(t != m and (t & m) == t for t in excluded)]
    require(len(excluded) == data['excluded_subsets'] == 103, 'excluded count')
    require(data['checked_subsets'] == 511, 'checked count')
    supplied = {tuple(row['seed']): row for row in data['minimal_families']}
    expected = {tuple(by_mask[m]['seed']): by_mask[m] for m in minimal}
    require(len(minimal) == len(data['minimal_families']) == 18
            and supplied == expected, 'minimal families')
    require(all(by_mask[m]['excluded'] == any((t & m) == t for t in minimal)
                for m in by_mask), 'minimal-family coverage')
    return dict(status='PASS', checked_subsets=511, checked_euler_choices=branches_checked,
                excluded_subsets=103, minimal_families=18,
                method='Independent factorization and integer divisor-sum comparisons')


if __name__ == '__main__':
    path = (Path(sys.argv[1]) if len(sys.argv) > 1 else
            Path(__file__).with_name('forced_family_certificate.json'))
    raw = path.read_bytes()
    result = check(json.loads(raw))
    result.update(certificate_sha256=hashlib.sha256(raw).hexdigest(),
                  checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    print(json.dumps(result, indent=2))
